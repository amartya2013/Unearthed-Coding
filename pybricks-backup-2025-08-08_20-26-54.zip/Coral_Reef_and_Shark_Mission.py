from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()


left_motor = Motor(Port.A,Direction.COUNTERCLOCKWISE)




#Right Motor = Port E
right_motor = Motor(Port.E,Direction.CLOCKWISE)

right_attachment = Motor(Port.B)
left_attachment = Motor(Port.F)

robot = DriveBase(left_motor,right_motor, 52, 200)


def right_turn(angle):
    hub.imu.reset_heading(0)
    while True:
        speed = angle - hub.imu.heading()
        robot.drive(0, speed * 3)
        if speed < 1:
            break
        wait(100)
    robot.stop()
    print(hub.imu.heading())

def left_turn(angle):
    hub.imu.reset_heading(0)
    while True:
        heading = hub.imu.heading()
        turned = (360 - heading) % 360  # How much we've turned left
        speed = angle - turned
        robot.drive(0, speed * -3.5)  # Same as right_turn, but uses 'turned'
        print(speed)
        if speed < 0.5:
            break
        wait(100)
    robot.stop()


robot.straight(100)

right_attachment.run_angle(1000, 500)

robot.straight(-300)

