from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

left_motor = Motor(Port.B,Direction.COUNTERCLOCKWISE)




right_motor = Motor(Port.F,Direction.CLOCKWISE)


robot = DriveBase(left_motor, right_motor, 56, 85)


def right_turn(angle):
    hub.imu.reset_heading(0)
    while True:
        error = angle - hub.imu.heading()
        robot.drive(0, error * 3)
        if error < 0.1:
            break
        wait(100)
    robot.stop()
    print(hub.imu.heading())

def left_turn(angle):
    hub.imu.reset_heading(0)
    while True:
        heading = hub.imu.heading()
        turned = (360 - heading) % 360  # How much we've turned left
        speed = angle - turned
        robot.drive(0, speed * -3.5)  # Same as right_turn, but uses 'turned'
        if speed < 0.5:
            break
        wait(100)
    robot.stop()

def Straight_Line_with_PID(MyDriveBase, Distance, kp, ki, kd):
    hub.imu.reset_heading(0)

    MyDriveBase.reset()

    target_heading = 0
    integral = 0
    last_error = 0

    base_speed = 900

    while MyDriveBase.distance() < Distance:
         current_heading = hub.imu.heading()
         error = target_heading - current_heading
         derivative = error -  last_error
         integral += error
         if integral > 20:
            integral = 20
         elif integral < -20:
            integral = -20

         correction = kp * error + ki * integral + kd * derivative
         MyDriveBase.drive(base_speed, correction)

         last_error = error
         print(MyDriveBase.distance(), ',', current_heading,',' ,error)
         wait(20)
    MyDriveBase.stop()
def gyro_straight(distance):
    robot.reset()
    hub.imu.reset_heading(0)
    while robot.distance() < distance:
        error = hub.imu.heading()
        robot.drive(500, 6 * (0 - error))
        wait(10)
    robot.stop(Stop.HOLD)


gyro_straight(5000)


