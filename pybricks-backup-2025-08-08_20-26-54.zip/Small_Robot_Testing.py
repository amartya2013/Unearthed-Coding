from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

left_motor = Motor(Port.E,Direction.COUNTERCLOCKWISE)




#Right Motor = Port D
right_motor = Motor(Port.A,Direction.CLOCKWISE)

right_attachment = Motor(Port.B)

left_attachment = Motor(Port.F)



# We Initialize the Drive Base for our robot
robot = DriveBase(left_motor,right_motor, 56, 92)

def turn_to_angle(target_angle, max_speed=200, min_speed=30, threshold=1.0):
    """
    Turns the robot to the specified absolute angle using the IMU.
    Parameters:
        target_angle: Desired heading in degrees (0 to 359)
        max_speed: Maximum turning speed
        min_speed: Minimum speed to avoid stalling
        threshold: How close (in degrees) to the target is acceptable
    """
    hub.imu.reset_heading(0)
    wait(200)  # Allow IMU to stabilize

    while True:
        current = hub.imu.heading()
        
        # Calculate shortest direction (positive = right, negative = left)
        error = (target_angle - current + 540) % 360 - 180

        # Exit if close enough
        if abs(error) <= threshold:
            break

        # Speed proportional to the error, clamped between min_speed and max_speed
        speed = max(min_speed, min(max_speed, abs(error) * 2))
        turn_direction = 1 if error > 0 else -1

        robot.drive(0, speed * turn_direction)

        wait(50)

    robot.stop()
    print(f"Turn complete. Final heading: {hub.imu.heading():.2f}")


def attachment_testing():
    right_attachment.run_time(500,-3060, wait= True)
    left_attachment.run_angle(500, -3060, wait=True)
# turn_to_angle(90, threshold=1)

robot.straight(10)