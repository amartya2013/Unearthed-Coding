from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

left_motor = Motor(Port.A,Direction.COUNTERCLOCKWISE)




right_motor = Motor(Port.E,Direction.CLOCKWISE)

right_attachment = Motor(Port.B)
left_attachment = Motor(Port.F)

robot = DriveBase(left_motor,right_motor, 56, 110)

def right_turn(angle):
    hub.imu.reset_heading(0)
    while True:
        speed = angle - hub.imu.heading()
        robot.drive(0, speed * 2)
        if speed < 1 and speed > -1:
            break
        wait(100)
    robot.stop()
    print(hub.imu.heading())

def battery_percentage(voltage):
    max_v = 7.6  # 7600 mV
    min_v = 6.4  # 6400 mV
    percent = (voltage / 1000 - min_v) / (max_v - min_v) * 100
    return round(min(max(percent, 0), 100))

def gyro_straight(distance):
    robot.reset()
    hub.imu.reset_heading(0)
    while robot.distance() < distance:
        error = hub.imu.heading()
        robot.drive(300, 6 * (0 - error))
        wait(10)
    robot.stop()

gyro_straight(1500)