from pybricks.hubs import PrimeHub 
from pybricks.pupdevices import Motor,ColorSensor
from pybricks.parameters import Port,Direction,Stop,Color
from pybricks.tools import StopWatch,wait
from pybricks.robotics import DriveBase


hub = PrimeHub()

# Left motor on Port A (change if needed)
left_motor = Motor(Port.A,Direction.COUNTERCLOCKWISE)




#Right Motor = Port D
right_motor = Motor(Port.E,Direction.CLOCKWISE)




# We Initialize the Drive Base for our robot
robot = DriveBase(left_motor,right_motor, 176, 375)


# timer = StopWatch()
# robot.use_gyro(True)
# hub.imu.reset_heading(0)

# print("Time, Distance (mm), Angle")
# while True:
#     robot.drive(700,0)
#     angle = hub.imu.heading()
#     dis = robot.distance()
#     time = timer.time()
#     print(f"{time},{dis},{angle}")
#     wait(100)
    
# robot.stop()

#Tell the robot to move forward


# # Telling Robot to drive in circle.
# robot.curve(1000, 366)



# robot.straight(1000)
# robot.turn(90)
# robot.straight(5000)




# while True:
#     if color_sensor.reflection() < 30:
#         robot.turn(-5)
#         robot.straight(30)
#     elif color_sensor.reflection() > 30:
#         robot.turn(5)
#         robot.straight(30)


# print("I stopping")
robot.reset()
while robot.stalled() == False:
    old_distance = robot.distance()
    robot.drive(700, 0)

    

robot.stop()
print(f"robot is stalled at {robot.distance()}")





