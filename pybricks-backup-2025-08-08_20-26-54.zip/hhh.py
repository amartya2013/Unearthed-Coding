from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

# Left motor on Port A (change if needed)
left_motor = Motor(Port.B,Direction.COUNTERCLOCKWISE)




#Right Motor = Port D
right_motor = Motor(Port.F,Direction.CLOCKWISE)


right_attachment = Motor(Port.A)
left_attachment = Motor(Port.E)

# We Initialize the Drive Base for our robot
robot = DriveBase(left_motor,right_motor, 56, 200)

# robot.straight(300)

# robot.straight(2000)
# robot.turn(-110)
# robot.straight(300)
# left_attachment.run(1000)
# wait(2000)
# robot.straight(-1000)
# right_attachment.run(10000)
# wait(2000

def gyro_turn(angle):
    hub.imu.reset_heading
    while hub.imu.heading() < angle:
        speed = angle - hub.imu.heading()
        robot.drive(0, speed * 3)
        print(hub.imu.heading())
    robot.stop()
def Straight_Line_with_PID(MyDriveBase, Distance, kp, ki, kd):
    hub.imu.reset_heading(0)

    MyDriveBase.reset()

    target_heading = 0
    integral = 0
    last_error = 0

    base_speed = 900

    while MyDriveBase.distance() < Distance:
         current_heading = hub.imu.heading()
         error = target_heading - current_heading
         derivative = error -  last_error
         integral += error
         if integral > 20:
            integral = 20
         elif integral < -20:
            integral = -20

         correction = kp * error + ki * integral + kd * derivative
         MyDriveBase.drive(base_speed, correction)

         last_error = error
         print(MyDriveBase.distance(), ',', current_heading,',' ,error)
         wait(20)
    MyDriveBase.stop()
        

def Straight_Line(distance):
    hub.imu.reset_heading(0)
    robot.straight(1000)
    print(hub.imu.heading())

def 

