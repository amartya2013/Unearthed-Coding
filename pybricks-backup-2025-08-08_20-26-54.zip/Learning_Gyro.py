from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch


hub = PrimeHub()

left_motor = Motor(Port.E,Direction.COUNTERCLOCKWISE)




#Right Motor = Port D
right_motor = Motor(Port.C,Direction.CLOCKWISE)



# We Initialize the Drive Base for our robot
robot = DriveBase(left_motor,right_motor, 62.4, 80)
                                                        QA!QQQQQ

robot.settings(500, 700)

for _ in range(4):
    robot.straight(500)
    robot.turn(90)

