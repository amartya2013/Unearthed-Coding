from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

hub = PrimeHub()

left_motor = Motor(Port.A,Direction.COUNTERCLOCKWISE)




right_motor = Motor(Port.E,Direction.CLOCKWISE)

right_attachment = Motor(Port.B)
left_attachment = Motor(Port.F)

robot = DriveBase(left_motor,right_motor, 56, 110)

def right_turn(angle):
    hub.imu.reset_heading(0)
    while True:
        speed = angle - hub.imu.heading()
        robot.drive(0, speed * 2)
        if speed < 1 and speed > -1:
            break
        wait(50)
    robot.stop()

def left_turn(angle):
    hub.imu.reset_heading(0)
    while True:
        heading = hub.imu.heading()
        turned = (360 - heading) % 360  # How much we've turned left
        speed = angle - turned
        robot.drive(0, speed * -3.5)  # Same as right_turn, but uses 'turned'
        print(speed)
        if speed < 1 and speed > -1:
            break
        wait(50)
    robot.stop()

def gyro_straight(distance):
    robot.reset()
    hub.imu.reset_heading(0)
    while robot.distance() < distance:
        error = hub.imu.heading()
        robot.drive(300, 6 * (0 - error))
        wait(10)
    robot.stop()

def gyro_reverse(distance):
    robot.reset()
    hub.imu.reset_heading(0)
    while 0 - robot.distance() < distance:
        error = hub.imu.heading()
        robot.drive(-300, 6 * (0 - error))
        print(robot.distance())

        wait(10)
    robot.stop()


#gyro_reverse(100)

def mission_1(): 
    gyro_straight(100)
    gyro_reverse(100)

def mission_2(): 
    for _ in range(4):
        gyro_straight(100)
        right_turn(90)

cm = 0
def make_decision():
    global cm
    print(cm)
    if cm == 1:
        print("hello")
        mission_1()
    elif cm == 2:
        print("goru")
        mission_2()
    elif cm == 3:
        print("chagol")
        left_turn(90)

while True:
    pressed = hub.buttons.pressed()
    hub.display.char(str(cm))
    if Button.LEFT in pressed:
        cm -= 1
        if cm > 9 or cm < 0: cm = 0
    if Button.RIGHT in pressed:
        cm += 1
        if cm > 9 or cm < 0: cm = 0
    if Button.BLUETOOTH in pressed:
        make_decision()
    wait(150)


