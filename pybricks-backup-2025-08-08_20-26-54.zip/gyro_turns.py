from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()


# Left motor on Port A (change if needed)
left_motor = Motor(Port.A,Direction.COUNTERCLOCKWISE)




#Right Motor = Port E
right_motor = Motor(Port.E,Direction.CLOCKWISE)

robot = DriveBase(left_motor,right_motor, 56, 200)

# right_attachment = Motor(Port.B)
# left_attachment = Motor(Port.F)


def right_turn(angle):
    hub.imu.reset_heading(0)
    while True:
        speed = angle - hub.imu.heading()
        robot.drive(0, speed * 2.5)
        if speed < 1:
            break
        wait(100)
    robot.stop()
    print(hub.imu.heading())

def left_turn(angle):
    hub.imu.reset_heading(0)
    while True:
        heading = hub.imu.heading()
        turned = (360 - heading) % 360
        speed = angle - turned
        robot.drive(0, speed * -2.5) 
        if speed < 0.5:
            break
        wait(100)
    robot.stop()
    print(hub.imu.heading())


left_turn(90)
wait(100)
right_turn(90)


